﻿# ShopSphere – Cloud Web Application

A simple PHP web application deployed on Azure App Service,
connected to Azure Database for MySQL.

Used for DAT6007 Cloud Computing assessments.
